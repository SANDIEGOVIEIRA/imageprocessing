# imageprocessing

Um pacote simples de processamento de imagens em Python usando Pillow.

## Funcionalidades

- Borrar imagens
- Redimensionar imagens

## Instalação

```bash
pip install imageprocessing
